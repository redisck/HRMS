package com.cumt.bean;

import com.cumt.model.Employee;

public class SalaryBasicBean {
	private Integer sbId;
	private String empName;
	private String empId;
	private Float sbBasic;
	private Integer sbEndowment;
	private Integer sbHospitalization;
	private Integer sbUnemployment;
	private Integer sbInjury;
	private Integer sbMaternity;
	private Integer sbHousing;
	private Float sbTraffic;
	private Float sbEatery;
	private Float sbTelephone;
	
	public Integer getSbId() {
		return sbId;
	}
	public void setSbId(Integer sbId) {
		this.sbId = sbId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public Float getSbBasic() {
		return sbBasic;
	}
	public void setSbBasic(Float sbBasic) {
		this.sbBasic = sbBasic;
	}
	public Integer getSbEndowment() {
		return sbEndowment;
	}
	public void setSbEndowment(Integer sbEndowment) {
		this.sbEndowment = sbEndowment;
	}
	public Integer getSbHospitalization() {
		return sbHospitalization;
	}
	public void setSbHospitalization(Integer sbHospitalization) {
		this.sbHospitalization = sbHospitalization;
	}
	public Integer getSbUnemployment() {
		return sbUnemployment;
	}
	public void setSbUnemployment(Integer sbUnemployment) {
		this.sbUnemployment = sbUnemployment;
	}
	public Integer getSbInjury() {
		return sbInjury;
	}
	public void setSbInjury(Integer sbInjury) {
		this.sbInjury = sbInjury;
	}
	public Integer getSbMaternity() {
		return sbMaternity;
	}
	public void setSbMaternity(Integer sbMaternity) {
		this.sbMaternity = sbMaternity;
	}
	public Integer getSbHousing() {
		return sbHousing;
	}
	public void setSbHousing(Integer sbHousing) {
		this.sbHousing = sbHousing;
	}
	public Float getSbTraffic() {
		return sbTraffic;
	}
	public void setSbTraffic(Float sbTraffic) {
		this.sbTraffic = sbTraffic;
	}
	public Float getSbEatery() {
		return sbEatery;
	}
	public void setSbEatery(Float sbEatery) {
		this.sbEatery = sbEatery;
	}
	public Float getSbTelephone() {
		return sbTelephone;
	}
	public void setSbTelephone(Float sbTelephone) {
		this.sbTelephone = sbTelephone;
	}

}
